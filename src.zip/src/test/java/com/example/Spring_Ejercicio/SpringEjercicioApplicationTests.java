package com.example.Spring_Ejercicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEjercicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
